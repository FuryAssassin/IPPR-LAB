I = imread('C:\Users\rithu\Downloads\mario.png');
figure;
subplot(2,2,1)
imshow(I)
title('Original Image')
Icomplement = imcomplement(I);
bw = imbinarize(rgb2gray(Icomplement));
subplot(2,2,2)
 
imshow(bw)
title('Binary Image')
out = bwskel(bw);
subplot(2,2,3)
imshow(labeloverlay(I,out,'Transparency',0))
title('skeletonized Image')
out2 = bwskel(bw,'MinBranchLength',15);
subplot(2,2,4)
imshow(labeloverlay(I,out2,'Transparency',0))
title('skeletonized Pruned Image')

