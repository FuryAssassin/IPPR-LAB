BW1 = imread('C:\Users\rithu\Downloads\league.jpg');
figure;
subplot(1,3,1)
imshow(BW1)
title('original image')
SE = strel('rectangle',[40 30]);
BW2 = imerode(BW1,SE);
subplot(1,3,2)
imshow(BW2)
title('Erosion image')
BW3 = imdilate(BW2,SE);
subplot(1,3,3)
imshow(BW3)
title('Dilation image')
